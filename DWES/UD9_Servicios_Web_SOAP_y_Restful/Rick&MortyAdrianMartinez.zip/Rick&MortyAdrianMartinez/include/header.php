<header>
    <?php
    ?>
    <a href="Rick">Rick</a> | <a href="<?php  $ruta?>Morty">Morty</a>
    <form action="#" method="GET">
        <input type="text" name="name">
        <button type="submit">Buscar</button>
    </form>
</header>