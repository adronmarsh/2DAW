<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Datos</title>
</head>
<body>
    <table>
        
        <?php
   
            $alfaMax5 = '/^\d{1,5}$/';
            $let3 = '/\w{3,}/';
            $dec = '/\d$/';
            $alfaMin50 = '/\w{50,}/';
            $alfa10_20 = '/^\w{10,20}$/';
            $fecha = '/^[\d{2}][\C\D{1}][\d{2}][\C\D{1}][\d{4}]$/';
            $sinEspacio = '/\S/';
               
                //   CODIGO
                if (isset($_POST['codigo'])){ //Comprobar que existe el campo
                    if (!preg_match($alfaMax5,$_POST['codigo'])){ //Comprobar si cumple con las expresiones regulares
                        echo 'ERROR: El código debe tener como máximo 5 dígitos y no puede contener ninguna letra!<br>';
                    }else {
                        echo '<tr><td>Código: '.$_POST['codigo'].'</td></tr>';
                    }
                }else{
                    echo 'ERROR: Debes rellenar el siguiente campo: Código';
                }

                // NOMBRE
                if (isset($_POST['nombre'])){
                    if (!preg_match($let3,$_POST['nombre'])){
                        echo 'ERROR: El nombre debe tener como mínimo 3 letras!<br>';
                    }else {
                        echo '<tr><td>Nombre: '.$_POST['nombre'].'</td></tr>';                    }
                }else{
                    echo 'ERROR: Debes rellenar el siguiente campo: Nombre';
                }

                // PRECIO
                if (isset($_POST['precio'])){
                    if (!preg_match($dec,$_POST['precio'])){
                        echo 'ERROR: El precio no puede contener ninguna letra o caracteres especiales!<br>';
                    }else {
                        echo '<tr><td>Precio: '.$_POST['precio'].'€</td></tr>';
                    }
                }else{
                    echo 'ERROR: Debes rellenar el siguiente campo: Precio';
                }

                // DESCRIPCIÓN
                if (isset($_POST['descripcion'])){
                    if (!preg_match($alfaMin50,$_POST['descripcion'])){
                        echo 'ERROR: La descripción debe tener como mínimo 50 letras!<br>';
                    }else {
                        echo '<tr><td>Descripción: '.$_POST['descripcion'].'</td></tr>';
                    }
                }else{
                    echo 'ERROR: Debes rellenar el siguiente campo: Descripción';
                }

                // FABRICANTE
                if (isset($_POST['fabricante'])){
                    if (!preg_match($alfa10_20,$_POST['fabricante'])){
                        echo 'ERROR: El número de fabricante debe tener entre 10 y 20 letras!<br>';
                    }else {
                        echo '<tr><td>Fabricante: '.$_POST['fabricante'].'</td></tr>';
                    }
                }else{
                    echo 'ERROR: Debes rellenar el siguiente campo: Fabricante';
                }

                //CANTIDAD
                if (isset($_POST['cantidad'])){
                    if (!preg_match($dec,$_POST['cantidad'])){
                        echo 'ERROR: La cantidad no puede contener ninguna letra o caracteres especiales!<br>';
                    }else {
                        echo '<tr><td>Cantidad: '.$_POST['cantidad'].'</td></tr>';
                    }
                }else{
                    echo 'ERROR: Debes rellenar el siguiente campo: Cantidad';
                }

                // FECHA
                if (isset($_POST['fecha'])){
                    if (!preg_match($dec,$_POST['fecha'])){
                        echo 'ERROR: La fecha debe contener el siguiente formato: XX/XX/XXXX !';
                    }else {
                        echo '<tr><td>Fecha: '.$_POST['fecha'].'</td></tr>';
                    }
                }else{
                    echo 'ERROR: Debes rellenar el siguiente campo: Fecha';
                }
          
          /*
            $_POST["codigo"]="";
            $_POST["nombre"]="";
            $_POST["precio"]="";
            $_POST["descripcion"]="";
            $_POST["fabricante"]="";
            $_POST["cantidad"]="";
            $_POST["fecha"]="";
          */
            
            

        ?>
        
    </table>
</body>
</html> 
