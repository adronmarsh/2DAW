<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Producto</title>
</head>
<body>
    <form name="formulario" method="post" action="datosAdrianMartinez.php">
        Código: <input type="text" name="codigo" id="codigo" /><br><br>
        Nombre: <input type="text" name="nombre" id="nombre" /><br><br>
        Precio: <input type="text" name="precio" id="precio" /><br><br>
        Descripción: <input type="area" name="descripcion" id="descripcion" /><br><br>
        Fabricante: <input type="text" name="fabricante" id="fabricante" /><br><br>
        Cantidad: <input type="number" name="cantidad" id="cantidad" /><br><br>
        Fecha de adquisición: <input type="date" name="fecha" id="fecha" /><br><br>
        
        <input type="submit" name="enviar" value="Enviar" />
    </form>
</body>
</html> 
