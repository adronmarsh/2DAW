<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Producto</title>
</head>
<body>
    
    <form method="get" action="datosAdrianMartinez.php">
        Código: <input type="text" name="codigo" id="codigo">
        Nombre: <input type="text" name="nombre" id="nombre">
        Precio: <input type="text" name="precio" id="precio">
        Descripción: <input type="area" name="descripcion" id="descripcion">
        Fabricante: <input type="text" name="fabricante" id="fabricante">
        Cantidad: <input type="number" name="cantidad" id="cantidad">
        Fecha de adquisición: <input type="date" name="fecha" id="fecha">
        <br>
        <input type="submit" value="Enviar">
    </form>

</form>
</body>
</html> 
