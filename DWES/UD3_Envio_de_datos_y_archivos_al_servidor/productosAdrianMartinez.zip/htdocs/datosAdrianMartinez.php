<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Datos</title>
</head>
<body>
    <table>
        
        <?php
            echo '<tr><td>Código: '.$_GET['codigo'].'</td></tr>';
            echo '<tr><td>Nombre: '.$_GET['nombre'].'</td></tr>';
            echo '<tr><td>Precio: '.$_GET['precio'].'€</td></tr>';
            echo '<tr><td>Descripción: '.$_GET['descripcion'].'</td></tr>';
            echo '<tr><td>Fabricante: '.$_GET['fabricante'].'</td></tr>';
            echo '<tr><td>Cantidad: '.$_GET['cantidad'].'</td></tr>';
            echo '<tr><td>Fecha: '.$_GET['fecha'].'</td></tr>';
        ?>
        
    </table>
</body>
</html> 
