<?php
// DOIT: añadir los datos de conexión a la base de datos
class Config {
	static public $bd_hostname = 'localhost';
	static public $bd_nombre = 'manganime';
	static public $bd_usuario = 'Goku';
	static public $bd_clave = 'Gohan';
	static public $css = 'estilo.css';
}
?>