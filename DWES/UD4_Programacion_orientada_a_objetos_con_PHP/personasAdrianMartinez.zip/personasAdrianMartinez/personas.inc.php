<?php
$personas = [
				['idContacto' => '1',
				  'nombre' => 'Luis',
				  'apellido1' => 'García',
				  'apellido2' => 'Hernández',
				  'telefono' => '651354781'],
	
				['idContacto' => '2',
				  'nombre' => 'Beatriz',
				  'apellido1' => 'Pérez',
				  'apellido2' => 'Tomás',
				  'telefono' => '668945366'],
	
				['idContacto' => '3',
				  'nombre' => 'Alicia',
				  'apellido1' => 'Grande',
				  'apellido2' => 'Romero',
				  'telefono' => '698591544'],
	
				['idContacto' => '4',
				  'nombre' => 'Javier',
				  'apellido1' => 'Muñoz',
				  'apellido2' => 'Alcalde',
				  'telefono' => '641122568'],
	
				['idContacto' => '5',
				  'nombre' => 'Zahara',
				  'apellido1' => 'Tena',
				  'apellido2' => 'Ausina',
				  'telefono' => '688845121'],
	
				['idContacto' => '6',
				  'nombre' => 'Pablo',
				  'apellido1' => 'Vergara',
				  'apellido2' => 'López',
				  'telefono' => '631520052'],
	
				['idContacto' => '7',
				  'nombre' => 'Cristina',
				  'apellido1' => 'Villa',
				  'apellido2' => 'Giner',
				  'telefono' => '632158645'],
			];