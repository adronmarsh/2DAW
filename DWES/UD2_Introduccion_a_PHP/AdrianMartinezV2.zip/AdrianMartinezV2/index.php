<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta http-equiv="expires" content="Sat, 07 feb 2016 00:00:00 GMT"/>
    <title>El portafolio</title>
    <link rel="stylesheet" href="style/style.css">
</head>

<header>
  <?php
    include 'includes/cabecera.inc.php';
  ?>
</header>

<body>
    <div class="container">
      <a href="https://www.linkedin.com/in/adrian-martinez-gil-918913237/">
          <div class="subcontainer"> 

            <div>
              
              <img id="img1" src="img/foto.png" alt=""> 
            </div>

            <table>
              <tr>
                <td style="font-weight:bold;" >Nombre:</td>
                <td>Adrián</td>
              </tr>
              <tr>
                <td style="font-weight:bold;">Apellidos:</td>
                <td>Martínez Gil</td>
              </tr>
              <tr>
                <td style="font-weight:bold;">DNI:</td>
                <td>12312348F</td>
              </tr>
              <tr>
                <td style="font-weight:bold;">Edad:</td>
                <td>18</td>
              </tr>
            </table>

        </div>
      </a> 
    </div>

</body>
<footer>
  <?php
    include_once 'includes/footer.inc.php';
  ?>
</footer>
</html>