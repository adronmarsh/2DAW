<ul id="menu">
      <li><a href="index.php">Presentacion</a></li>
      <li><a href="skills.php">Skills</a></li>
      <li><a href="trabajos.php">Trabajos</a></li>    
      <li><a href="hobbies.php">Hobbies</a></li>
    </ul>
