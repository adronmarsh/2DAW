<div id="name"><h2 >Adrián Martínez</h2></div>
        <ul class="lista">
            <li><a href="index.php"> Inicio</a></li>
            <li><a href="altaAdrianMartinez.php"> Alta</a></li>
            <li><a href="juegoAdrianMartinez.php"> Juego</a></li>
        </ul>