// const avatar = document.getElementById("avatar");

// avatar.addEventListener("mouseover", function () {
//     avatar.style.width = "22rem";
//     avatar.style.height = "22rem";
//     avatar.style.opacity = ".6";
// });

// avatar.addEventListener("mouseout", function () {
//     avatar.style.width = "";
//     avatar.style.height = "";
//     avatar.style.opacity = "1";
// });