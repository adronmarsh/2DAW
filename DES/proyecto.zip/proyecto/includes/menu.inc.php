<ul class="lista">
    <li><img src="img/revels_logo.png" alt=""></li>
    <li><a href="index.php"> Inicio</a></li>
    <li><a href=""> Alta</a></li>
    <li><a href=""> Juego</a></li>
</ul>