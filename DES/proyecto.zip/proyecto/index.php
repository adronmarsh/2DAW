<?php
  $error_message='<span class="error">ERROR: Este campo no puede estar vacío.</span><br>';
  
  $user_format='/^\w/';
  $error_message_user='<span class="error">ERROR: Este campo debe tener como mínimo 3 letras y no puede contener espacios!</span><br>';

  $password_format='/^(?=.*[!@#$%^&*-])(?=.*[0-9])(?=.*[A-Z]).{8,20}$/';
  $error_message_password="<span class='error'><strong>ERROR: La contraseña debe cumplir con los siguientes requisitos:</strong><br>Un mínimo de 8 caracteres.<br>Al menos una letra mayúscula.<br>Al menos un número.<br>Al menos uno de los siguientes caracteres especiales !@#$%^&'-</span><br>";
  //$_POST['user']="";
  //$_POST['password']="";
?>
<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>Revels | Registro</title>
  </head>
  <body>
  <header>
      <?php
        include 'includes/menu.inc.php';
      ?>
  </header>
    <h1>Login</h1>
    <form name="registro" action="#" method="post">
      <!--USUARIO-->
      Usuario <br><input type="text" name="user" id="user" required
      <?php
        $_POST['user']=trim($_POST['user']);//eliminamos los posibles espacios de delante y atrás para que no nos produzcan problemas
        if (empty($_POST['user'])){
      ?>
          value=""><br><br>
      <?php    
          echo $error_message;  
        }
        else{
          if (!preg_match($user_format,$_POST['user'])){ //Comprueba si cumple con las expresiones regulares
      ?> 
            value="<?=$_POST['user']?>"><br><br>
      <?php
            echo $error_message_user;
          }
          else{
      ?> 
            value="<?=$_POST['user']?>"><br><br>
      <?php
          }
        }
      ?>
      <!--PASSWORD-->
      Contraseña<br><input type="text" name="password" id="password" required
      <?php
        $_POST['password']=trim($_POST['password']);//eliminamos los posibles espacios de delante y atrás para que no nos produzcan problemas
        if (empty($_POST['password'])){
      ?>  
          value=""><br><br>
      <?php      
          echo $error_message;  
        }
        else{
          if (!preg_match($password_format,$_POST['password'])){ //Comprueba si cumple con las expresiones regulares
      ?> 
            value="<?=$_POST['password']?>"><br><br>
      <?php
            echo $error_message_password;
          }
          else{
      ?> 
            value="<?=$_POST['password']?>"><br><br>
      <?php
          }
        }
      ?>
      <input type="submit" name="Enviar">
    </form>

  </body>
</html>
